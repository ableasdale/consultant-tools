#!/usr/bin/env ruby

if ARGV.size != 1
  puts "apply_steps.rb usage: apply_steps.rb <marklogic_endpoint>"
  exit -1
end

def load_applied_steps
  return [] if !File.exists? STEPS_FILE
  open(STEPS_FILE, "r+").read.split.map { |line| line.split.first }
end

def should_apply?(step)
  !@applied_steps.include? name_of step
end

def log_transation(step)
  open(STEPS_FILE, "a+") { |file| file.puts "#{name_of step} #{Time.now}" }
end

def name_of(step)
  File.basename(step)
end

def apply(step)
  puts "About to apply: #{name_of step}."
  `java -cp "#{@current_dir}/cmd-xcc/*" XccManager #{@marklogic_xcc_url} #{step}`
  raise "Failed to apply #{name_of step}." if $?.exitstatus != 0

  log_transation(step)
end

def always_apply(step)
  puts "About to apply: #{name_of step}."
  `java -cp "#{@current_dir}/cmd-xcc/*" XccManager #{@marklogic_xcc_url} #{step}`
  raise "Failed to apply #{name_of step}." if $?.exitstatus != 0
end

STEPS_FILE = "transactions/steps.transactions" 

@marklogic_xcc_url = ARGV[0]
@current_dir = File.expand_path(File.dirname(__FILE__))
@applied_steps = load_applied_steps

puts "Actions to run once"
steps_dir = File.join(@current_dir, "steps")
steps = Dir.glob(File.join(steps_dir, "*.xqy")).sort
steps.select{ |step| should_apply? step }.each { |step| apply step }
puts "Completed.."

puts "\nActions to run every time the build is executed"
always_run_dir = File.join(@current_dir, "steps/always-run")
always_run = Dir.glob(File.join(always_run_dir, "*.xqy")).sort
always_run.select{|step| step}.each {|step| always_apply step }
puts "Completed.."
