javac -cp marklogic-xcc-4.2.5.jar *.java
jar cvfm xcc.jar Manifest *.java *.class

echo "The jar has now been created; call using the params:
java -classpath marklogic-xcc-4.2.5.jar:xcc.jar XccManager xcc://admin:admin@localhost:9999/CasperDocuments [file1 file2 file3 file4 file5]
(for example):
java -classpath marklogic-xcc-4.2.5.jar:xcc.jar XccManager xcc://admin:admin@localhost:9999/CasperDocuments /home/casper/casper/core/ops/deploy/marklogic/steps/01_create_database.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/02_base_level_database_settings.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/03_add_database_range_indexes.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/04_add_phrase_throughs.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/05_add_phrase_arounds.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/06_set_database_word_lexicons.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/07_configure_roles.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/08_configure_privileges.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/09_create_user_with_privileges.xqy /home/casper/casper/core/ops/deploy/marklogic/steps/10_set_appserver_default_user.xqy"
